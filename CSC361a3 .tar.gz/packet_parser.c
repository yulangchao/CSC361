/* http://inst.eecs.berkeley.edu/~ee122/fa07/projects/p2files/packet_parser.c*/

/* Demonstration program of reading packet trace files recorded by pcap
 * (used by tshark and tcpdump) and dumping out some corresponding information
 * in a human-readable form.
 *
 * Note, this program is limited to processing trace files that contains
 * UDP packets.  It prints the timestamp, source port, destination port,
 * and length of each such packet.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <endian.h>
#include <math.h>
#include <pcap.h>

#define MAX_STR_LEN 20
#define MAX_NUM_CONNECTION 10000
/* We've included the UDP header struct for your ease of customization.
 * For your protocol, you might want to look at netinet/tcp.h for hints
 * on how to deal with single bits or fields that are smaller than a byte
 * in length.
 *
 * Per RFC 768, September, 1981.
 */
struct UDP_hdr {
	u_short	uh_sport;		/* source port */
	u_short	uh_dport;		/* destination port */
	u_short	uh_ulen;		/* datagram length */
	u_short	uh_sum;			/* datagram checksum */
};



struct connection{ 
        char ip_src[20];  /*source ip*/ 
        char ip_dst[20];  /*destination ip*/ 
        int port_src;      /*source port number*/ 
        int port_dst;      /*destination port number*/ 
        int thflags;
        int ttl;
        int ip_p;
        int type;
        int ccode;
        int ip_off;
        int ip_id;
        int ip_len;
        int seq;
        int syn_count;          /*flag count*/ 
	int fin_count; 
	int rst_count; 
	struct timeval starting_time; 
	struct timeval ending_time; 
        double duration; 
	int num_packet_src;     /*number of packets sent out by source*/ 
	int num_packet_dst;     /*number of packets sent out by destination*/ 
	int num_total_packets; 
        int cur_data_len;
	int cur_data_len_src;  
	int cur_data_len_dst; 
	int cur_total_data_len; 
        double max_win_size;  /*max window size*/ 
       // uint16_t 
        double min_win_size;  /*min window size*/ 
        double sum_win_size; 
//	struct round_trip rtt_ary_src[MAX_NUM_CONNECTION/4]; /*assume 1000*/ 
	int rtt_ary_src_len;    /*the size of the rtt_ary_src array*/ 
//	struct round_trip rtt_ary_dst[MAX_NUM_CONNECTION/4]; /*assume 1000*/ 
	int rtt_ary_dst_len;    /*the size of the rtt_ary_dst array*/ 
	int is_set; 
} con[10000];

struct round_trip{


};


/* Some helper functions, which we define at the end of this file. */

/* Returns a string representation of a timestamp. */
const char *timestamp_string(struct timeval ts);

/* Report a problem with dumping the packet with the given timestamp. */
void problem_pkt(struct timeval ts, const char *reason);

/* Report the specific problem of a packet being too short. */
void too_short(struct timeval ts, const char *truncated_hdr);

/* ()
 *
 * This routine parses a packet, expecting Ethernet, IP, and UDP headers.
 * It extracts the UDP source and destination port numbers along with the UDP
 * packet length by casting structs over a pointer that we move through
 * the packet.  We can do this sort of casting safely because libpcap
 * guarantees that the pointer will be aligned.
 *
 * The "ts" argument is the timestamp associated with the packet.
 *
 * Note that "capture_len" is the length of the packet *as captured by the
 * tracing program*, and thus might be less than the full length of the
 * packet.  However, the packet pointer only holds that much data, so
 * we have to be careful not to read beyond it.
 */
	struct ip *ip;
	struct icmphdr *icmp;
struct UDP_hdr *udp;
	struct icmp *icmp1;
 
 
void dump_UDP_packet(const unsigned char *packet, struct timeval ts,
			unsigned int capture_len)
{

	unsigned int IP_header_length;

	/* For simplicity, we assume Ethernet encapsulation. */

	if (capture_len < sizeof(struct ether_header))
		{
		/* We didn't even capture a full Ethernet header, so we
		 * can't analyze this any further.
		 */
		too_short(ts, "Ethernet header");
		return;
		}

	/* Skip over the Ethernet header. */
	packet += sizeof(struct ether_header);
	capture_len -= sizeof(struct ether_header);

	if (capture_len < sizeof(struct ip))
		{ /* Didn't capture a full IP header */
		too_short(ts, "IP header");
		return;
		}

	ip = (struct ip*) packet;
        icmp=(struct icmphdr*) (ip+1);
        icmp1=(struct icmp*) (ip+1);
	IP_header_length = ip->ip_hl * 4;	/* ip_hl is in 4-byte words */

	if (capture_len < IP_header_length)
		{ /* didn't capture the full IP header including options */
		too_short(ts, "IP header with options");
		return;
		}
 packet += IP_header_length;
       udp = (struct UDP_hdr*) packet;

	
	}

int main(int argc, char *argv[])
	{
	pcap_t *pcap;
	const unsigned char *packet;
	char errbuf[PCAP_ERRBUF_SIZE];
	struct pcap_pkthdr header;
      
	/* Skip over the program name. */
	++argv; --argc;

	/* We expect exactly one argument, the name of the file to dump. */
	if ( argc != 2 )
		{
		fprintf(stderr, "program requires one more argument, W for windows and L for linux\n");
		exit(1);
		}

	pcap = pcap_open_offline(argv[0], errbuf);
	if (pcap == NULL)
		{
		fprintf(stderr, "error reading pcap file: %s\n", errbuf);
		exit(1);
		}
        int i=0;
        int u=0;
        int o=0;
        int l=0;

//////////////////////////////////////windows
if (strcmp(argv[1],"W")==0 ){
	  while ((packet = pcap_next(pcap, &header)) != NULL ){
		dump_UDP_packet(packet, header.ts, header.caplen);
                


                
                if(ip->ip_p==0x01){
                strcat(con[i].ip_src,inet_ntoa(ip->ip_src));
                strcat(con[i].ip_dst,inet_ntoa(ip->ip_dst));
                con[i].ttl=ip->ip_ttl;
                con[i].ip_p=ip->ip_p;
                con[i].ip_off=ntohs(ip->ip_off);
                con[i].type=icmp->type;
                con[i].ccode=icmp->code;
                con[i].ip_id=ntohs(ip->ip_id);
                con[i].ip_len=ntohs(ip->ip_len);
                con[i].starting_time=header.ts;
                con[i].seq=icmp1->icmp_seq;
                 i++;
                }


        } 
  
        int j=0;
        
        int va,va1=0;
        double rtt[1000];
        char * first_dst  ;  
        char * first_src   ; 
        int bg=0;
//Find all data
// while (va1<i&&j<i){    
           int exist=0;
           int port=0;
           int c=0;
           char *route[1000];
           struct timeval routetime[1000];
           int start;
           int k,b,comp=0;
           int g=va1;
           int end=0;
           struct timeval lastone;
           struct timeval first_time;
           for(j=va1;j<i;j++){  
           
               if((con[j].ttl!=1 )&&exist!=1){
               continue;
               }
                
               if(con[j].ttl==1 && con[j].type==8){
               first_dst=con[j].ip_dst;
               first_src=con[j].ip_src;
               port=con[j].ip_p;
               comp=con[j].ip_id;
               first_time=con[j].starting_time;
               start=j;
	       exist=1;
               }

               if(strcmp(con[j].ip_src,first_dst)==0){
                //   comp=con[j].ip_id;
                   lastone=con[j].starting_time;
                   va=1;
                   if(strcmp(con[j+1].ip_src,first_dst)!=0){
                       va1=j+1;
                       end=j;
                       break;                      
                   }            
                }
             
               if(strcmp(con[j].ip_dst,first_src)==0){
               
                    route[c]=con[j].ip_src;  
                    routetime[c]=con[j].starting_time;
                    
                   // rtt[c]=(double)(con[j].starting_time.tv_sec-first_time.tv_sec)*1000+(double)((con[j].starting_time.tv_usec-first_time.tv_usec)/1000);
		    c++;
                 //   printf("%dms\n",(int)(rtt[c]));
               }              
            }
            if(exist==0){
           //  break;
            }


            int h,w,e=0;
            for (h=0;h<c;h++){
                   for(w=h+1;w<c;w++){
                          if(strcmp(route[h],route[w])==0){
                              for (e=w;e<(c-1);e++){
                                 route[e]=route[e+1];
                                 routetime[e]=routetime[e+1];
                              }
                              c--;
                              w--;
                          }


                   }
            }
       


//print information       
       printf("The IP address of the source node: %s\n",first_src);
       printf("The IP address of ultimate destination node: %s\n",first_dst);   
       printf("The IP addresses of the intermediate destination nodes:\n"); 
       int m,n,l=0;
       for(n=0;n<(c);n++){
                 if(strcmp(route[n],first_dst)==0){
                      continue;
                 }
      		 printf("	router%d: %s\n",n+1,route[n]);
        }



       int count=0;
       int offset_num=0;
       for(n=g;n<i;n++){
             if(con[n].ip_id==comp){
               count++;
             } 
       }
       int p=count-1;
       for(m=g;m<i;m++){
             if(con[m].ip_id==comp && p>0){
               offset_num+=con[m].ip_len-20;
               p--;
             } 
       }
       int t=0;
       double totalstart[1000];
       int porttype[1000];
       int r=i;
            for (h=0;h<r;h++){
                  
              porttype[h]=con[h].ip_p;
            }
            for (h=0;h<r;h++){
                   for(w=h+1;w<r;w++){
                          if(porttype[h]==porttype[w]){
                              for (e=w;e<(r-1);e++){
                                 porttype[e]=porttype[e+1];
                              }
                              r--;
                              w--;
                          }


                   }
            }



 	printf("\nThe values in the protocol field of IP headers:\n");
        for(h=0;h<r;h++){
        if(porttype[h]==0x01) 
        printf("	1: ICMP\n");
        }
        for(h=0;h<r;h++){
        if(porttype[h]==0x11) 
        printf("	17: UDP\n");
        }
	// terminate
        if(count==1){
	printf("\n\nThe number of fragments created from the original datagram is: %d\n",count-1);
	}else{
	printf("\n\nThe number of fragments created from the original datagram is: %d\n",count);
	}
	printf("The offset of the last fragment is: %d\n\n",offset_num);

        //printf("rtt is %f \n",rtt[1]);
 
        int y=0;
        int x=0;
        for(l=0;l<(c);l++){
                    double ttstart=0;
   		    double sdt=0;

//printf("%d\n",l+1);
                    for(x=bg;x<end;x++){
                        if(con[x].ttl==l+1){
                             start=x;
			         //        	printf("%d\n",start+1);
                             break;
		              	}
		                }
                    
            //        printf("%f\n",(double)(routetime[l].tv_sec)*1000+(double)(routetime[l].tv_usec/1000));
            //        printf("%f\n",(double)(con[start].starting_time.tv_sec)*1000+(double)((con[start].starting_time.tv_usec)/1000));

                  
                    for(t=0;t<count;t++){
          		 totalstart[t]=(double)(routetime[l].tv_sec-con[start+t].starting_time.tv_sec)*1000+(double)((routetime[l].tv_usec-con[start+t].starting_time.tv_usec)/1000);
               //        printf("%f\n",totalstart[t]);
                         ttstart+=totalstart[t];
   		    }
      
                 rtt[l]=ttstart/count;
                    for(y=0;y<count;y++){
               //         printf("%f\n",(totalstart[y]-rtt[l])*(totalstart[y]-rtt[l]));
                        sdt+=(totalstart[y]-rtt[l])*(totalstart[y]-rtt[l]);
   		    }
                //       printf("%f\n",sdt);  
                if(strcmp(route[l],first_dst)!=0){                 
                 if(count==1){
		printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,route[l],(int)(rtt[l]),0);
                 }else{
       		 printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,route[l],(int)(rtt[l]),(int)(sqrt(sdt/(count-1))));
		}
		}
        }
                    for(x=bg;x<end;x++){
                        if(con[x].ttl==l+1){
                             start=x;
			        //         	printf("%d\n",start+1);
                             
		              	}
		                }        
        
        
        
        
                 double a=(double)(lastone.tv_sec-con[start].starting_time.tv_sec)*1000+(double)((lastone.tv_usec-con[start].starting_time.tv_usec)/1000);
                 printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,first_dst,(int)a,0);
        

        bg=end+1;
        
        
        printf("\n___________________________________________________________________________________________________________________________\n\n");

        int aa=0;
        for (aa=0;aa<i;aa++){
        //    printf("%d\n",con[aa].seq);

        }










////////////////////////////////////////////Linux
 }else if (strcmp(argv[1],"L")==0 ){
          int abc=0;

	  while ((packet = pcap_next(pcap, &header)) != NULL ){
		dump_UDP_packet(packet, header.ts, header.caplen);
   
   
               // printf("%d,%d\n",abc++,ntohs(udp->uh_dport));
                if(ip->ip_p==0x01  ||(ip->ip_p==0x11 && (ntohs(udp->uh_dport)!=1900))){
                strcat(con[i].ip_src,inet_ntoa(ip->ip_src));
                strcat(con[i].ip_dst,inet_ntoa(ip->ip_dst));
                con[i].ttl=ip->ip_ttl;
                con[i].ip_p=ip->ip_p;
                con[i].ip_off=ntohs(ip->ip_off);
                con[i].type=icmp->type;
                con[i].ccode=icmp->code;
                con[i].ip_id=ntohs(ip->ip_id);
                con[i].ip_len=ntohs(ip->ip_len);
                con[i].starting_time=header.ts;
         //       printf("%d,%d\n",con[i].ttl,con[i].type);

                 i++;
           //      printf("%d\n",i);
                }


          } 
      	   int j=0;

       	   int va,va1=0;
           double rtt[1000];
           char * first_dst;  
           char * first_src; 
           int bg=0;
           
  // while (va1<i&&j<i){ 
           int exist=0;
           int port=0;
           int c=0;
           char *route[1000];
           struct timeval routetime[1000];
           int start;
           int k,b,comp=0;
           int g=va1;
           int end=0;
           struct timeval lastone;
           struct timeval first_time;
           for(j=va1;j<i;j++){
               
               if((con[j].type==9 || con[j].ttl!=1 )&&exist!=1){
               continue;
               }
               if(con[j].ttl==1){
            //   printf("%s,%d,%d\n",con[j].ip_src,j,con[j].ip_id);
               first_dst=con[j].ip_dst;
               first_src=con[j].ip_src;
               port=con[j].ip_p;
               comp=con[j].ip_id;
               first_time=con[j].starting_time;
               start=j;
               exist=1;
               }

               if(strcmp(con[j].ip_src,first_dst)==0){
                //   comp=con[j].ip_id;
                   lastone=con[j].starting_time;
                   va=1;
                   if(strcmp(con[j+1].ip_src,first_dst)!=0){
                       va1=j+1;
                       end=j;
                       break;                      
                   }            
                }
             
               if(strcmp(con[j].ip_dst,first_src)==0){
               
                    if(c>0){       
                   	 if(strcmp(con[j].ip_src,route[c-1])==0){
                             continue;
                         }
                    }
                    route[c]=con[j].ip_src;  
                    routetime[c]=con[j].starting_time;
                   // rtt[c]=(double)(con[j].starting_time.tv_sec-first_time.tv_sec)*1000+(double)((con[j].starting_time.tv_usec-first_time.tv_usec)/1000);
		    c++;
                 //   printf("%dms\n",(int)(rtt[c]));
               }   
               }           


            int h,w,e=0;
            for (h=0;h<c;h++){
                   for(w=h+1;w<c;w++){
                          if(strcmp(route[h],route[w])==0){
                              for (e=w;e<(c-1);e++){
                                 route[e]=route[e+1];
                                 routetime[e]=routetime[e+1];
                              }
                              c--;
			      w--;
                          }


                   }
            }

//print information       
       printf("The IP address of the source node: %s\n",first_src);
       printf("The IP address of ultimate destination node: %s\n",first_dst);   
       printf("The IP addresses of the intermediate destination nodes:\n"); 
       int m,n,l=0;
       for(n=0;n<(c);n++){
                 if(strcmp(route[n],first_dst)==0){
                      continue;
                 }
      		 printf("	router%d: %s\n",n+1,route[n]);
        }



       int count=0;
       int offset_num=0;
       for(n=g;n<i;n++){
             if(con[n].ip_id==comp){
               count++;
             } 
       }
       int p=count-1;
       for(m=g;m<i;m++){
             if(con[m].ip_id==comp && p>0){
               offset_num+=con[m].ip_len-20;
               p--;
             } 
       }
       int t=0;
       double totalstart[1000];
       int porttype[1000];
       int r=i;
            for (h=0;h<r;h++){
                  
              porttype[h]=con[h].ip_p;
            }
            for (h=0;h<r;h++){
                   for(w=h+1;w<r;w++){
                          if(porttype[h]==porttype[w]){
                              for (e=w;e<(r-1);e++){
                                 porttype[e]=porttype[e+1];
                              }
                              r--;
			      w--;
                          }


                   }
            }
       // printf("%d",r);

	printf("\nThe values in the protocol field of IP headers:\n");
        for(h=0;h<r;h++){
        if(porttype[h]==0x01) 
        printf("	1: ICMP\n");
        }
        for(h=0;h<r;h++){
        if(porttype[h]==0x11) 
        printf("	17: UDP\n");
        }
	// terminate
        if(count==1){
	printf("\n\nThe number of fragments created from the original datagram is: %d\n",count-1);
	}else{
	printf("\n\nThe number of fragments created from the original datagram is: %d\n",count);
	}
	printf("The offset of the last fragment is: %d\n\n",offset_num);

    //    printf("rtt is %f \n",rtt[1]);
 
        int y=0;       
        int x=0;
        for(l=0;l<c;l++){
                    double ttstart=0;
   		    double sdt=0;
                    
                    for(x=bg;x<end;x++){
                        if(con[x].ttl==l+1){
                             start=x;
			}
		    }


                    for(t=0;t<count;t++){
          		 totalstart[t]=(double)(routetime[l].tv_sec-con[start+t].starting_time.tv_sec)*1000+(double)((routetime[l].tv_usec-con[start+t].starting_time.tv_usec)/1000);
                       //  printf("%f\n",totalstart[t]);
                         ttstart+=totalstart[t];
   		    }
      
                 rtt[l]=ttstart/count;
                    for(y=0;y<count;y++){
                  //      printf("%f\n",(totalstart[y]-rtt[l])*(totalstart[y]-rtt[l]));
                        sdt+=(totalstart[y]-rtt[l])*(totalstart[y]-rtt[l]);
   		    }
                  //        printf("%f\n",sdt);  
                if(strcmp(route[l],first_dst)!=0){                 
                 if(count==1){
		printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,route[l],(int)(rtt[l]),0);
                 }else{
       		 printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,route[l],(int)(rtt[l]),(int)(sqrt(sdt/(count-1))));
		}
                }
        }
                    for(x=bg;x<end;x++){
                        if(con[x].ttl==l+1){
                             start=x;
			        //         	printf("%d\n",start+1);
                             
		              	}
		                }        
        
        
        
        
                 double a=(double)(lastone.tv_sec-con[start].starting_time.tv_sec)*1000+(double)((lastone.tv_usec-con[start].starting_time.tv_usec)/1000);
                 printf("The avg RRT between %s and %s is: %d ms, the s.d. is: %d ms\n",first_src,first_dst,(int)a,0);
        bg=end+1;
        printf("\n___________________________________________________________________________________________________________________________\n\n");
//}

////////////////////wrong input
}else{
		fprintf(stderr, "program requires the last argument as : W for windows or L for linux\n");
		exit(1);

}     
	return 0;
	}


/* Note, this routine returns a pointer into a static buffer, and
 * so each call overwrites the value returned by the previous call.
 */
const char *timestamp_string(struct timeval ts)
	{
	static char timestamp_string_buf[256];

	sprintf(timestamp_string_buf, "%d.%06d",
		(int) ts.tv_sec, (int) ts.tv_usec);

	return timestamp_string_buf;
	}

void problem_pkt(struct timeval ts, const char *reason)
	{
	fprintf(stderr, "%s: %s\n", timestamp_string(ts), reason);
	}

void too_short(struct timeval ts, const char *truncated_hdr)
	{
	fprintf(stderr, "packet with timestamp %s is truncated and lacks a full %s\n",
		timestamp_string(ts), truncated_hdr);
	}
