This pakcet_parser.c is to to analyze a trace of IP datagrams:

The methods to run it:
  
If packet is from Lunix System:
     Type: ./packet_parser traceroute-linux.pcapng L                    (traceroute-linux.pcapng is the packet name)

If packet is from Windows System:
     Type: ./packet_parser ip-trace-1 W                                  (ip-trace-1 is the packet name)

	A.List the IP address of the source node, the IP address of ultimate destination node, the IP
	  address(es) of the intermediate destination node(s).  If multiple the intermediate destination
	  nodes exist, they should be ordered by their hop count to the source node in the increasing
	  order.

	B.Check the IP header of all datagrams in the trace  le, and list the set of values in the
	  protocol field of the IP headers.  Note that only di erent values should be listed in a set.

        C.Find the number of fragments. And the last offset.

        D.Calculate the average and standard deviation of round trip time(s) between the source node
	  and the intermediate destination node (s) and the average round trip time between the source
	  node and the ultimate destination node.  
