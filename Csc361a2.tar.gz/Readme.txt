This pakcet_parse.c is to to analyze the TCP protocol behavior:

	A.To find out the number of connections from cap-file

	B.To show the details of connection like:

               Connection 48:
 		 Source Address: 192.168.1.164
 		 Destination address: 132.170.108.140
 		 Source Port: 1247
 		 Destination Port: 80
 		 Status:  S2F1 
  		 Start time:  1139256984.809547 
  		 End Time:  1139257000.386780 
  		 Duration:  15.577233 
  		 Number of packets sent from Source to Destination: 9
  		 Number of packets sent from Destination to Source: 11
  		 Total number of packets: 20
  		 Number of data bytes sent from Source to Destination: 779
  		 Number of data bytes sent from Destination to Source: 11724
  		 Total number of data bytes:  12503
  		 END


	C.To count the number of complete connection , number of reset TCP connections and number of TCP connections that were still open when the trace capture ended

	D.Colect data from cap file:

           a.Calculate the minimum, mean, and maximum time durations of the complete TCP connections

	   b.Calculate the minimum, mean, and maximum RTT (Round Trip Time) values of the complete TCP connections

	   c.Calculate the minimum, mean, and maximum number of packets (both directions) sent on the complete TCP connections

 	   d.Calculate the minimum, mean, and maximum receive window sizes (both sides) of the complete TCP connections.
