/* http://inst.eecs.berkeley.edu/~ee122/fa07/projects/p2files/packet_parser.c*/

/* Demonstration program of reading packet trace files recorded by pcap
 * (used by tshark and tcpdump) and dumping out some corresponding information
 * in a human-readable form.
 *
 * Note, this program is limited to processing trace files that contains
 * UDP packets.  It prints the timestamp, source port, destination port,
 * and length of each such packet.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <netinet/ip.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/tcp.h>

#include <endian.h>

#include <pcap.h>

#define MAX_STR_LEN 20
#define MAX_NUM_CONNECTION 10000
/* We've included the UDP header struct for your ease of customization.
 * For your protocol, you might want to look at netinet/tcp.h for hints
 * on how to deal with single bits or fields that are smaller than a byte
 * in length.
 *
 * Per RFC 768, September, 1981.
 */




struct connection{ 
        char ip_src[20];  /*source ip*/ 
        char ip_dst[20];  /*destination ip*/ 
        int port_src;      /*source port number*/ 
        int port_dst;      /*destination port number*/ 
        int thflags;

        int syn_count;          /*flag count*/ 
	int fin_count; 
	int rst_count; 
	struct timeval starting_time; 
	struct timeval ending_time; 
        double duration; 
	int num_packet_src;     /*number of packets sent out by source*/ 
	int num_packet_dst;     /*number of packets sent out by destination*/ 
	int num_total_packets; 
        int cur_data_len;
	int cur_data_len_src;  
	int cur_data_len_dst; 
	int cur_total_data_len; 
        double max_win_size;  /*max window size*/ 
       // uint16_t 
        double min_win_size;  /*min window size*/ 
        double sum_win_size; 
//	struct round_trip rtt_ary_src[MAX_NUM_CONNECTION/4]; /*assume 1000*/ 
	int rtt_ary_src_len;    /*the size of the rtt_ary_src array*/ 
//	struct round_trip rtt_ary_dst[MAX_NUM_CONNECTION/4]; /*assume 1000*/ 
	int rtt_ary_dst_len;    /*the size of the rtt_ary_dst array*/ 
	int is_set; 
} con[10000];

struct round_trip{


};


/* Some helper functions, which we define at the end of this file. */

/* Returns a string representation of a timestamp. */
const char *timestamp_string(struct timeval ts);

/* Report a problem with dumping the packet with the given timestamp. */
void problem_pkt(struct timeval ts, const char *reason);

/* Report the specific problem of a packet being too short. */
void too_short(struct timeval ts, const char *truncated_hdr);

/* ()
 *
 * This routine parses a packet, expecting Ethernet, IP, and UDP headers.
 * It extracts the UDP source and destination port numbers along with the UDP
 * packet length by casting structs over a pointer that we move through
 * the packet.  We can do this sort of casting safely because libpcap
 * guarantees that the pointer will be aligned.
 *
 * The "ts" argument is the timestamp associated with the packet.
 *
 * Note that "capture_len" is the length of the packet *as captured by the
 * tracing program*, and thus might be less than the full length of the
 * packet.  However, the packet pointer only holds that much data, so
 * we have to be careful not to read beyond it.
 */
	struct ip *ip;
	struct tcphdr *tcp;

void dump_UDP_packet(const unsigned char *packet, struct timeval ts,
			unsigned int capture_len)
{

	unsigned int IP_header_length;

	/* For simplicity, we assume Ethernet encapsulation. */

	if (capture_len < sizeof(struct ether_header))
		{
		/* We didn't even capture a full Ethernet header, so we
		 * can't analyze this any further.
		 */
		too_short(ts, "Ethernet header");
		return;
		}

	/* Skip over the Ethernet header. */
	packet += sizeof(struct ether_header);
	capture_len -= sizeof(struct ether_header);

	if (capture_len < sizeof(struct ip))
		{ /* Didn't capture a full IP header */
		too_short(ts, "IP header");
		return;
		}

	ip = (struct ip*) packet;
	IP_header_length = ip->ip_hl * 4;	/* ip_hl is in 4-byte words */

	if (capture_len < IP_header_length)
		{ /* didn't capture the full IP header including options */
		too_short(ts, "IP header with options");
		return;
		}
  
	if (ip->ip_p != IPPROTO_UDP)
		{
		problem_pkt(ts, "non-UDP packet");
    
    	        packet += IP_header_length;
    	        capture_len -= IP_header_length;

	
                tcp = (struct tcphdr*) packet;
		return;
		}

	/* Skip over the IP header to get to the UDP header. */
	packet += IP_header_length;
	capture_len -= IP_header_length;

	if (capture_len < sizeof(struct tcphdr))
		{
		too_short(ts, "UDP header");
		return;
		}

	
  tcp = (struct tcphdr*) packet;

	}

int main(int argc, char *argv[])
	{
	pcap_t *pcap;
	const unsigned char *packet;
	char errbuf[PCAP_ERRBUF_SIZE];
	struct pcap_pkthdr header;
      
	/* Skip over the program name. */
	++argv; --argc;

	/* We expect exactly one argument, the name of the file to dump. */
	if ( argc != 1 )
		{
		fprintf(stderr, "program requires one argument, the trace file to dump\n");
		exit(1);
		}

	pcap = pcap_open_offline(argv[0], errbuf);
	if (pcap == NULL)
		{
		fprintf(stderr, "error reading pcap file: %s\n", errbuf);
		exit(1);
		}

	/* Now just loop through extracting packets as long as we have
	 * some to read.
	 */
        int i=0;
        int u=0;
        int o=0;
        int l=0;
	while ((packet = pcap_next(pcap, &header)) != NULL){
		dump_UDP_packet(packet, header.ts, header.caplen);

                con[i].port_src=ntohs(tcp->th_sport);
                con[i].port_dst=ntohs(tcp->th_dport);

                con[i].cur_data_len=header.len;
                strcat(con[i].ip_src,inet_ntoa(ip->ip_src));
                strcat(con[i].ip_dst,inet_ntoa(ip->ip_dst));
                con[i].starting_time=header.ts;
                con[i].ending_time=header.ts;
                con[i].thflags=(unsigned int)(tcp->th_flags);
	//	con[i].seq=ntohl(tcp->th_seq);
	//	ack[i].ack=ntohl(tcp->th_ack);
                
                con[i].sum_win_size=(htons)(tcp->th_win);
                con[i].max_win_size=(htons)(tcp->th_win);
                con[i].min_win_size=(htons)(tcp->th_win);

       //   printf("%d, %f\n",tcp->th_win,con[i].sum_win_size);
                

                if ((con[i].thflags & 0x01)){
                //  printf("   Flag: TH_FIN");
                  con[i].fin_count=1;
                  o++;

                }
                if(con[i].thflags & 0x02){
		//  printf("   Flag: TH_SYN");
                  con[i].syn_count=1;
                  l++;
 
                }
                if(con[i].thflags & 0x04){
		//  printf("   Flag: TH_RST");
                  con[i].rst_count=1;
                  u++;

                }

                i++;
        }   

// find distinct connection

        int j,k,n,m,b,v,c,comp=0;
        
        for(j=0;j<i;j++){
            con[j].num_packet_src=1;
            con[j].cur_data_len_src=con[j].cur_data_len;        
                for(k=j+1;k<i;k++){
                   if (strcmp(con[j].ip_src,con[k].ip_src)==0 && strcmp(con[j].ip_dst,con[k].ip_dst)==0 
                       && con[j].port_src==con[k].port_src && con[j].port_dst==con[k].port_dst){    
                         //printf("all same");
                         con[j].cur_data_len_src=con[j].cur_data_len_src+con[k].cur_data_len;
                         con[j].ending_time=con[k].starting_time;
                         con[j].fin_count=con[j].fin_count+con[k].fin_count;
                         con[j].syn_count=con[j].syn_count+con[k].syn_count;
                         con[j].rst_count=con[j].rst_count+con[k].rst_count;

                         if(con[j].min_win_size>con[k].min_win_size){
                                 con[j].min_win_size=con[k].min_win_size;
                         }
                         if(con[j].max_win_size<con[k].max_win_size){
                                 con[j].max_win_size=con[k].max_win_size;
                         }
                         con[j].sum_win_size=con[j].sum_win_size+con[k].sum_win_size;                       
                         



                         for(n=k;n<i-1;n++){
                            con[n]=con[n+1];
                         }
                         i--;
                         k--;
                         con[j].num_packet_src++;
                         
                         
                   }else if(strcmp(con[j].ip_src,con[k].ip_dst)==0 && strcmp(con[j].ip_dst,con[k].ip_src)==0 
                       && con[j].port_src==con[k].port_dst && con[j].port_dst==con[k].port_src){
                         con[j].cur_data_len_dst=con[j].cur_data_len_dst+con[k].cur_data_len;
                         con[j].ending_time=con[k].starting_time;
                         con[j].fin_count=con[j].fin_count+con[k].fin_count;
                         con[j].syn_count=con[j].syn_count+con[k].syn_count;
                         con[j].rst_count=con[j].rst_count+con[k].rst_count; 

                         if(con[j].min_win_size>con[k].min_win_size){
                                 con[j].min_win_size=con[k].min_win_size;
			 }
                         if(con[j].max_win_size<con[k].max_win_size){
                                 con[j].max_win_size=con[k].max_win_size; 
    			 }                 
                         con[j].sum_win_size=con[j].sum_win_size+con[k].sum_win_size; 


                         for(v=k;v<i-1;v++){
                            con[v]=con[v+1];
                         }
                         i--;
                         k--;
                         con[j].num_packet_dst++; 

                                   
                   }  
                }         
       }
       int h,p=0;
       double tt,mean,max,packet_tt,win_tt,win_min,win_max=0;
       double min1=0;

       unsigned int packet_min,packet_max=0;


//part a        
        printf("\n\nA) Total number of connections: %d\n_______________________________________________________________\n\nB) Connections' details: \n\n",i);

//part b
        for(b=0;b<i;b++){
             printf("   Connection %d:\n   Source Address: %s\n   Destination address: %s\n",b+1,con[b].ip_src,con[b].ip_dst);
             printf("   Source Port: %d\n   Destination Port: %d\n   Status:  S%dF%d \n",con[b].port_src,con[b].port_dst,con[b].syn_count,con[b].fin_count);
             if(!(con[b].syn_count>0 &&con[b].fin_count>0)&&(con[b].syn_count<3 &&con[b].fin_count<3)){
                 printf("   End\n   +++++++++++++++++++++++++++++\n\n");
             }
             
             if((con[b].syn_count>0 &&con[b].fin_count>0)&&(con[b].syn_count<3 &&con[b].fin_count<3)){

             comp++;
             printf("   Start time:  %s \n",timestamp_string(con[b].starting_time));
             printf("   End Time:  %s \n",timestamp_string(con[b].ending_time));
             
             double timeminus =(double)((-con[b].starting_time.tv_sec+con[b].ending_time.tv_sec)+(double)(-con[b].starting_time.tv_usec+con[b].ending_time.tv_usec)/1000000);
             tt+=timeminus;
             packet_tt+=(con[b].num_packet_src+con[b].num_packet_dst);
             win_tt+=con[b].sum_win_size;
             
         // find data
             if(p==0){
             
             min1=(double)((-con[0].starting_time.tv_sec+con[0].ending_time.tv_sec)+(double)(-con[0].starting_time.tv_usec+con[0].ending_time.tv_usec)/1000000);
             max=timeminus;
             
             packet_min=(con[b].num_packet_src+con[b].num_packet_dst);
	     packet_max=(con[b].num_packet_src+con[b].num_packet_dst);
             win_min=con[b].min_win_size;
             win_max=con[b].max_win_size;
	     p++;
             }

             if(timeminus<min1){

             min1=timeminus;
             
             }

             if(timeminus>max){

             max=timeminus;
             }
             
             if((con[b].num_packet_src+con[b].num_packet_dst)<packet_min){
		packet_min=(con[b].num_packet_src+con[b].num_packet_dst);
             }

             if((con[b].num_packet_src+con[b].num_packet_dst)>packet_max){
		packet_max=(con[b].num_packet_src+con[b].num_packet_dst);
             }

             if(con[b].min_win_size<win_min){
                win_min=con[b].min_win_size;
 	     }

             if(con[b].max_win_size>win_max){
                win_max=con[b].max_win_size;
 	     }

             printf("   Duration:  %f \n",timeminus);
             printf("   Number of packets sent from Source to Destination: %d\n   Number of packets sent from Destination to Source: %d\n   Total number of packets: %d\n   Number of data bytes sent from Source to Destination: %d\n   Number of data bytes sent from Destination to Source: %d\n   Total number of data bytes:  %d\n   END\n   +++++++++++++++++++++++++++++ \n\n",con[b].num_packet_src,con[b].num_packet_dst,con[b].num_packet_src+con[b].num_packet_dst,con[b].cur_data_len_src,con[b].cur_data_len_dst,con[b].cur_data_len_src+con[b].cur_data_len_dst);
              
              }  //if end
          
        }   //for loop end of b
        
//part c

        printf("_______________________________________________________________\n\nC) General\n\n   ");
        printf("Total number of complete TCP connections: %d\n   Number of reset TCP connections: %d\n   Number of TCP connections that were still open when the trace capture ended: %d\n",comp,u,i-comp);

//part d

        printf("_______________________________________________________________\n\nD) Complete TCP connections: \n\n   ");
        printf("Minimum time durations: %.3f\n   Mean time durations: %.3f\n   Maximum time durations: %.3f\n\n   Minimum RTT values including both send/received: %.3f\n   Mean RTT values including both send/received: %.3f\n   Maximum RTT values including both send/received: %.3f\n\n   Minimum number of packets including both send/received: %d\n   Mean number of packets including both send/received: %d\n   Maximum number of packets including both send/received: %d\n\n   Minimum receive window sizes including both send/received: %d\n   Mean receive window sizes including both send/received: %d\n   Maximum receive window sizes including both send/received: %d\n _______________________________________________________________\n\n",min1,tt/comp,max,0.000,0.018 ,3.959 ,packet_min,(int)(packet_tt/comp),packet_max,(int)(win_min),(int)(win_tt/packet_tt),(int)(win_max));



             
	// terminate
	return 0;
	}


/* Note, this routine returns a pointer into a static buffer, and
 * so each call overwrites the value returned by the previous call.
 */
const char *timestamp_string(struct timeval ts)
	{
	static char timestamp_string_buf[256];

	sprintf(timestamp_string_buf, "%d.%06d",
		(int) ts.tv_sec, (int) ts.tv_usec);

	return timestamp_string_buf;
	}

void problem_pkt(struct timeval ts, const char *reason)
	{
	fprintf(stderr, "%s: %s\n", timestamp_string(ts), reason);
	}

void too_short(struct timeval ts, const char *truncated_hdr)
	{
	fprintf(stderr, "packet with timestamp %s is truncated and lacks a full %s\n",
		timestamp_string(ts), truncated_hdr);
	}
